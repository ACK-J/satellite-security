#!/usr/bin/env python3
import socket, threading, re, cmd, sys

HOST, PORT = "127.0.0.1", 5000
CONTROL_PORT = 5001
FRAME_LEN = 16

capture_buf = []
filters = []
manips = []
repeater_on = False
rx_enabled = False  # off until you run `rx start`

def crc16(data: bytes) -> int:
    crc = 0xFFFF
    for b in data:
        crc ^= b
        for _ in range(8):
            if crc & 1: crc = (crc >> 1) ^ 0xA001
            else: crc >>= 1
    return crc & 0xFFFF

def apply_filters(pkt_hex: str) -> bool:
    if not filters:
        return True
    return any(re.search(p, pkt_hex) for p in filters)

def apply_manips(pkt: bytearray) -> bytearray:
    for op, offset, val in manips:
        if offset >= len(pkt):
            continue
        if op == "XOR": pkt[offset] ^= val
        elif op == "OR": pkt[offset] |= val
        elif op == "AND": pkt[offset] &= val
        elif op == "NOT": pkt[offset] = (~pkt[offset]) & 0xFF
    return pkt

class RFQuackShim(cmd.Cmd):
    intro = "RFQuack-style shim. Type help or ?"
    prompt = "rq> "

    def __init__(self):
        super().__init__()
        self.s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.s.connect((HOST, PORT))
        self.rx_thread = threading.Thread(target=self.rx_loop, daemon=True)
        self.rx_thread.start()

    def rx_loop(self):
        global repeater_on, rx_enabled
        while True:
            pkt = self.s.recv(FRAME_LEN)
            if not pkt: continue
            if not rx_enabled: continue
            pkt_hex = pkt.hex().upper()
            if apply_filters(pkt_hex):
                capture_buf.append(pkt_hex)
                print(f"\n[RX] {pkt_hex}")
                if repeater_on:
                    out = apply_manips(bytearray(pkt))
                    c = crc16(out[:-2]).to_bytes(2, "big")
                    out = out[:-2] + c
                    self.s.sendall(out)

    # --- RADIO (cosmetic) ---
    def do_radio(self, arg):
        print("[radio] set:", arg)

    def do_rx(self, arg):
        """rx start|stop"""
        global rx_enabled
        if arg.strip().startswith("start"):
            rx_enabled = True
            print("[rx] start")
        else:
            rx_enabled = False
            print("[rx] stop")

    # --- FILTER ---
    def do_packet_filter(self, arg):
        """packet_filter add <regex> | list | clear"""
        parts = arg.split()
        if not parts: return
        if parts[0] == "add" and len(parts) > 1:
            filters.append(parts[1])
            print(f"[filter] added: {parts[1]}")
        elif parts[0] == "list":
            for i, f in enumerate(filters): print(f"{i}: {f}")
        elif parts[0] in ("clear", "off"):
            filters.clear()
            print("[filter] cleared")
        else:
            print("usage: packet_filter add <regex> | list | clear")

    # --- MANIP ---
    def do_packet_manipulator(self, arg):
        """packet_manipulator add <XOR|OR|AND|NOT> <offset> <0xVAL> | list | clear"""
        parts = arg.split()
        if not parts: return
        if parts[0] == "add" and len(parts) == 4:
            op, offset, val = parts[1].upper(), int(parts[2]), int(parts[3],16)
            manips.append((op, offset, val))
            print(f"[manip] add {op} @{offset} {hex(val)}")
        elif parts[0] == "list":
            for i, r in enumerate(manips): print(f"{i}: {r}")
        elif parts[0] in ("clear", "off"):
            manips.clear()
            print("[manip] cleared")
        else:
            print("usage: packet_manipulator add <OP> <offset> <0xVAL> | list | clear")

    # --- REPEATER ---
    def do_repeater(self, arg):
        global repeater_on
        if "on" in arg:
            repeater_on = True
            print("[repeater] on")
        else:
            repeater_on = False
            print("[repeater] off")

    # --- SEND ---
    def do_send(self, arg):
        """send <hex16> (CRC auto-fixed)"""
        hexs = arg.strip().replace(" ", "")
        try:
            pkt = bytearray.fromhex(hexs)
        except ValueError:
            print("[send] bad hex")
            return
        if len(pkt) != FRAME_LEN:
            print(f"[send] expected {FRAME_LEN} bytes (32 hex chars incl CRC), got {len(pkt)}")
            return
        c = crc16(pkt[:-2]).to_bytes(2,"big")
        pkt = pkt[:-2] + c
        self.s.sendall(pkt)
        print("[TX]", pkt.hex().upper())

    # --- DUMP ---
    def do_dump(self, arg):
        if not capture_buf:
            print("No captures")
            return
        if arg.strip().startswith("n"):
            try: n = int(arg.split()[1])
            except: n = 5
            for line in capture_buf[-n:]: print(line)
        else:
            print("Last:", capture_buf[-1])

    # --- JAM ---
    def do_jam(self, arg):
        if "start" in arg:
            duty = 0.5
            if "--duty" in arg:
                try: duty = float(arg.split("--duty")[1].strip())
                except: pass
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as cs:
                cs.connect((HOST, CONTROL_PORT))
                cs.sendall(f"JAM {duty}\n".encode())
                print(cs.recv(128).decode().strip())
        else:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as cs:
                cs.connect((HOST, CONTROL_PORT))
                cs.sendall(b"JAM 0\n")
                print(cs.recv(128).decode().strip())

    def do_exit(self, arg):
        sys.exit(0)

if __name__ == "__main__":
    RFQuackShim().cmdloop()

