#!/usr/bin/env python3
import socket, time, argparse

FRAME_LEN = 16
PRE, SYNC = b"\xAA\xAA", b"\x55\x55"
SAT_ID = 0xA1

def crc16(data: bytes) -> int:
    crc = 0xFFFF
    for b in data:
        crc ^= b
        for _ in range(8):
            if crc & 1: crc = (crc >> 1) ^ 0xA001
            else: crc >>= 1
    return crc & 0xFFFF

def make_cmd(seq, mode, cmd):
    pkt = PRE + SYNC + bytes([SAT_ID, mode, seq, cmd]) + b"\x00"*6
    c = crc16(pkt).to_bytes(2, "big")
    return pkt + c

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=5000)
    ap.add_argument("--send-every", type=int, default=7, help="seconds")
    args = ap.parse_args()

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((args.host, args.port))

    seq = 0
    cmds = [0x02, 0x03, 0x04]  # 02=OFF, 03=ON, 04=SET_MODE
    while True:
        cmd = cmds[seq % len(cmds)]
        pkt = make_cmd(seq, 0x01, cmd)
        s.sendall(pkt)
        print(f"[GS] TX cmd={cmd:02X} seq={seq:02X}")
        seq = (seq + 1) % 256
        time.sleep(args.send_every)

if __name__ == "__main__":
    main()

