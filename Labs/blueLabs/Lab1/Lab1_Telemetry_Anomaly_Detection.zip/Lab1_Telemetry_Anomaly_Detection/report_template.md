# Lab 1 — Telemetry Anomaly Detection (Report)

**Name:** <your name>

**Date:** <date>

**Summary:** 2–3 sentences on what you found.


## Findings
List each anomaly type with start/end timestamps and your reasoning.


## Methods
- Data sanity checks performed

- Thresholds and windows used

- Any plots/screenshots included


## Impact + Recommendations
- What could this mean operationally?

- What would you watch next orbit?

- Any rule changes (thresholds, alerts)?

