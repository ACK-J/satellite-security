#!/usr/bin/env python3
import argparse, json
from datetime import datetime, timedelta
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

def iso(t): return datetime.fromisoformat(t)

def find_time_skews(ts):
    bad = []
    start = None
    prev = iso(ts[0])
    for i, t in enumerate(ts[1:], 1):
        cur = iso(t)
        if cur < prev and start is None:
            start = i-1
        if start is not None and cur >= prev:
            bad.append((start, i-1))
            start = None
        prev = cur
    if start is not None:
        bad.append((start, len(ts)-1))
    return bad

def find_gaps(ts, max_gap_s=30):
    gaps = []
    prev = iso(ts[0])
    for i, t in enumerate(ts[1:], 1):
        cur = iso(t)
        if (cur - prev).total_seconds() > max_gap_s:
            gaps.append((i-1, i))
        prev = cur
    return gaps

def find_seq_replay(seq):
    # Expect +1 increments; detect duplicates that create a replay window
    bad = []
    start = None
    for i in range(1, len(seq)):
        if seq[i] <= seq[i-1] and start is None:
            start = i-1
        if start is not None and seq[i] > seq[i-1]:
            bad.append((start, i-1))
            start = None
    if start is not None:
        bad.append((start, len(seq)-1))
    return bad


def find_oob_and_roc(series, ts, lo, hi, max_rate_per_min):
    # kept for voltage OOB; ROC part deprecated for temp
    oob = []
    # OOB spans
    in_oob = None
    for i, v in enumerate(series):
        if (v < lo or v > hi) and in_oob is None:
            in_oob = i
        if in_oob is not None and (lo <= v <= hi):
            oob.append((in_oob, i-1)); in_oob=None
    if in_oob is not None: oob.append((in_oob, len(series)-1))
    roc = []  # not used
    return oob, roc


def find_temp_spikes(series, ts, min_step_c=8.0):
    # Detect abrupt 5s jumps: abs delta between consecutive samples >= min_step_c
    spans = []
    n = len(series)
    for i in range(n-1):
        if abs(series[i+1] - series[i]) >= min_step_c:
            spans.append((i, i+1))
    return spans



def find_context_inconsistency(df):
    bad = []
    in_bad = None
    for i, r in df.iterrows():
        if (r["sunlight"] == False) and (r["op_mode"] == "CHARGE") and (r["battery_i"] > 0.3):
            if in_bad is None: in_bad = i
        else:
            if in_bad is not None: bad.append((in_bad, i-1)); in_bad=None
    if in_bad is not None: bad.append((in_bad, len(df)-1))
    return bad

def find_stuck(series, min_minutes=10):
    bad = []
    window = int((min_minutes*60)/5)  # assuming ~5s cadence
    run_start = 0
    for i in range(1, len(series)):
        if series[i] != series[i-1]:
            if i - run_start >= window:
                bad.append((run_start, i-1))
            run_start = i
    if len(series) - run_start >= window:
        bad.append((run_start, len(series)-1))
    return bad

def find_crc_burst(flags, ts, window_min=2, frac=0.2):
    bad = []
    w = int((window_min*60)/5)
    for i in range(0, len(flags)-w):
        win = flags[i:i+w]
        bad_frac = (win == False).mean()
        if bad_frac >= frac:
            bad.append((i, i+w-1))
    # merge overlaps
    merged = []
    for s,e in bad:
        if not merged or s > merged[-1][1]+1:
            merged.append([s,e])
        else:
            merged[-1][1] = max(merged[-1][1], e)
    return [(s,e) for s,e in merged]


def to_spans(spans, ts, type_):
    norm = []
    for s,e in spans:
        start_ts = ts[s]
        end_ts = ts[e]
        try:
            if pd.to_datetime(start_ts) > pd.to_datetime(end_ts):
                start_ts, end_ts = end_ts, start_ts
        except Exception:
            pass
        norm.append({"type": type_, "start": start_ts, "end": end_ts})
    return norm


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("csv")
    ap.add_argument("--plot", default=None)
    args = ap.parse_args()

    df = pd.read_csv(args.csv)
    ts = df["timestamp"].tolist()

    findings = []

    # 1) time skew
    findings += to_spans(find_time_skews(ts), ts, "time_skew")

    # 2) gaps
    findings += to_spans(find_gaps(ts, 30), ts, "beacon_gap")

    # 3) replay by seq behavior
    findings += to_spans(find_seq_replay(df["seq"].to_numpy()), ts, "replay_seq")
    # 4) voltage oob + targeted temp spikes
    oob, _ = find_oob_and_roc(df["battery_v"].to_numpy(), ts, 6.8, 9.0, 999)
    findings += to_spans(oob, ts, "oob_voltage")

    spikes = find_temp_spikes(df["battery_temp_c"].to_numpy(), ts, 8.0)
    findings += to_spans(spikes, ts, "roc_temp")

    # 5) context inconsistency


    findings += to_spans(find_context_inconsistency(df), ts, "context_inconsistent_charge_in_eclipse")

    # 6) stuck sensor
    findings += to_spans(find_stuck(df["radio_rssi_dbm"].to_numpy(), 10), ts, "stuck_sensor_rssi")

    # 7) CRC burst
    flags = df["packet_crc_ok"].astype(bool).to_numpy()
    findings += to_spans(find_crc_burst(flags, ts, 2, 0.2), ts, "crc_burst")

    out = {"student": "", "findings": findings}
    print(json.dumps(out, indent=2))

    if args.plot:
        plt.figure()
        plt.plot(pd.to_datetime(df["timestamp"]), df["battery_v"])
        plt.title("Battery Voltage Over Time")
        plt.xlabel("Time")
        plt.ylabel("V")
        plt.tight_layout()
        plt.savefig(args.plot)

if __name__ == "__main__":
    main()
