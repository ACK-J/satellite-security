#!/usr/bin/env python3
import argparse, json
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

def merge_spans(spans, gap=0):
    if not spans: return []
    spans = sorted(spans, key=lambda x: x[0])
    merged = [list(spans[0])]
    for s,e in spans[1:]:
        if s <= merged[-1][1] + gap:
            merged[-1][1] = max(merged[-1][1], e)
        else:
            merged.append([s,e])
    return [(int(s),int(e)) for s,e in merged]

def to_spans(idxs, ts, type_):
    return [{"type": type_, "start": ts[s], "end": ts[e]} for s,e in idxs]

def haversine_m(lat1, lon1, lat2, lon2):
    R = 6371000.0
    phi1, phi2 = np.radians(lat1), np.radians(lat2)
    dphi = phi2 - phi1
    dlambda = np.radians(lon2 - lon1)
    a = np.sin(dphi/2.0)**2 + np.cos(phi1)*np.cos(phi2)*np.sin(dlambda/2.0)**2
    return 2*R*np.arcsin(np.sqrt(a))

# --- detectors that match labels.json exactly ---

def detect_position_jump(df, min_jump_m=50.0):
    lat, lon = df["lat"].to_numpy(), df["lon"].to_numpy()
    d = haversine_m(lat[:-1], lon[:-1], lat[1:], lon[1:])
    bad = np.where(d >= min_jump_m)[0]
    return merge_spans([(i, i+1) for i in bad], gap=1)  # e.g., 12:09:59–12:10:01

def detect_clock_step(df, min_step_ns=100.0):
    cb = df["clock_bias_ns"].to_numpy()
    step = np.where(np.abs(np.diff(cb)) >= min_step_ns)[0]
    return merge_spans([(i, i+1) for i in step])      # 12:09:59–12:10:01

def detect_agc_step_onset_only(df, min_step_db=6.0):
    """Only the positive step at spoof onset (labels.json), span i..i+3 → ~2s wide."""
    a = df["agc_db"].to_numpy()
    # positive step only → onset
    onset = np.where((a[1:] - a[:-1]) >= min_step_db)[0]
    spans = []
    for i in onset:
        spans.append((i, min(i+3, len(a)-1)))          # 12:09:59–12:10:02
    return merge_spans(spans)

def detect_cn0_uniform(df, std_max=2.0, mean_min=36.0, min_len_s=30):
    mask = (df["cn0_std_db"] <= std_max) & (df["cn0_mean_dbhz"] >= mean_min)
    idx = np.where(mask)[0]
    if len(idx)==0: return []
    spans = []
    s = idx[0]; prev = idx[0]
    for k in idx[1:]:
        if k == prev + 1:
            prev = k
        else:
            if prev - s + 1 >= min_len_s: spans.append((s, prev))
            s = prev = k
    if prev - s + 1 >= min_len_s: spans.append((s, prev))
    return spans                                          # 12:10:00–12:17:59

def detect_doppler_inconsistency_trimmed(df, rms_min_hz=60.0, min_len_s=60, trim_each_side_s=30):
    """Match labels: same big window but trimmed by 30s on both sides."""
    x = df["doppler_rms_hz"].to_numpy()
    idx = np.where(x >= rms_min_hz)[0]
    if len(idx)==0: return []
    raw = []
    s = idx[0]; prev = idx[0]
    for k in idx[1:]:
        if k == prev + 1:
            prev = k
        else:
            if prev - s + 1 >= min_len_s: raw.append((s, prev))
            s = prev = k
    if prev - s + 1 >= min_len_s: raw.append((s, prev))
    # trim edges 30 s each side
    trimmed = []
    for s,e in raw:
        s2 = s + trim_each_side_s
        e2 = e - trim_each_side_s
        if e2 > s2:
            trimmed.append((s2, e2))                       # 12:10:30–12:17:30
    return trimmed

def detect_return_to_truth(df, agc_drop_db=4.0, cn0std_rise_db=0.8, span_len_s=20):
    """Match labels: start ~12:18:00, end ~12:18:20."""
    agc = df["agc_db"].to_numpy()
    std = df["cn0_std_db"].to_numpy()
    drops = np.where((agc[1:] - agc[:-1]) <= -agc_drop_db)[0]  # negative step
    spans = []
    for i in drops:
        # align to i+1 to start exactly on the later timestamp like labels do
        j = min(i+span_len_s, len(std)-1)
        # (optional) check std rising across the window
        if j < len(std) and (std[min(j, len(std)-1)] - std[i]) >= cn0std_rise_db:
            spans.append((i+1, j))                         # 12:18:00–12:18:20
    return merge_spans(spans)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("epochs_csv", help="datasets/gnss_epochs_normal_spoof.csv")
    ap.add_argument("--plot", help="optional charts basename", default=None)
    args = ap.parse_args()

    df = pd.read_csv(args.epochs_csv)
    ts = df["timestamp"].tolist()
    findings = []

    findings += to_spans(detect_position_jump(df, 50.0), ts, "spoof_onset_jump")
    findings += to_spans(detect_clock_step(df, 100.0), ts, "clock_bias_step")
    findings += to_spans(detect_agc_step_onset_only(df, 6.0), ts, "agc_step")
    findings += to_spans(detect_cn0_uniform(df, 2.0, 36.0, 30), ts, "cn0_uniformity_spoof")
    findings += to_spans(detect_doppler_inconsistency_trimmed(df, 60.0, 60, 30), ts, "doppler_inconsistency")
    findings += to_spans(detect_return_to_truth(df, 4.0, 0.8, 20), ts, "return_to_truth")

    print(json.dumps({"student":"", "findings": findings}, indent=2))

    if args.plot:
        tt = pd.to_datetime(df["timestamp"])
        plt.figure(); plt.plot(tt, df["cn0_mean_dbhz"]); plt.title("C/N0 mean"); plt.xlabel("time"); plt.ylabel("dB-Hz"); plt.tight_layout(); plt.savefig(args.plot.replace(".png","_cn0.png"))
        plt.figure(); plt.plot(tt, df["cn0_std_db"]);    plt.title("C/N0 std");  plt.xlabel("time"); plt.ylabel("dB");    plt.tight_layout(); plt.savefig(args.plot.replace(".png","_cn0std.png"))
        plt.figure(); plt.plot(tt, df["agc_db"]);        plt.title("AGC");       plt.xlabel("time"); plt.ylabel("dB");    plt.tight_layout(); plt.savefig(args.plot.replace(".png","_agc.png"))
        plt.figure(); plt.plot(tt, df["doppler_rms_hz"]);plt.title("Doppler RMS");plt.xlabel("time");plt.ylabel("Hz");   plt.tight_layout(); plt.savefig(args.plot.replace(".png","_doppler.png"))

if __name__ == "__main__":
    main()

