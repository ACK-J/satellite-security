#!/usr/bin/env python3
import json, sys
from datetime import datetime
def parse_iso(t): return datetime.fromisoformat(t)
def overlap(a, b):
    s1, e1 = parse_iso(a["start"]), parse_iso(a["end"])
    s2, e2 = parse_iso(b["start"]), parse_iso(b["end"])
    latest_start = max(s1, s2); earliest_end = min(e1, e2)
    if latest_start >= earliest_end: return 0.0
    inter = (earliest_end - latest_start).total_seconds()
    denom = max((e1 - s1).total_seconds(), 1.0)
    return inter / denom
def load_truth(path):
    with open(path) as f: raw = json.load(f)
    truth = {}
    for item in raw:
        t = item["type"]
        truth.setdefault(t, []).append({"start": item["start_timestamp"], "end": item["end_timestamp"]})
    return truth
def load_student(path):
    with open(path) as f: raw = json.load(f)
    pred = {}
    for item in raw.get("findings", []):
        t = item["type"]
        pred.setdefault(t, []).append({"start": item["start"], "end": item["end"]})
    return pred
def score(truth, pred):
    types = sorted(truth.keys()); total_tp=total_fn=total_fp=0; per_type=[]
    for t in types:
        gt = truth.get(t, []); pd = pred.get(t, []); used=set(); tp=0
        for g in gt:
            for i,p in enumerate(pd):
                if i in used: continue
                if overlap(g,p) >= 0.2: used.add(i); tp+=1; break
        fn = len(gt) - tp; fp = max(0, len(pd) - tp)
        total_tp += tp; total_fn += fn; total_fp += fp
        per_type.append((t,tp,fn,fp))
    prec = total_tp/(total_tp+total_fp) if (total_tp+total_fp)>0 else 0.0
    rec = total_tp/(total_tp+total_fn) if (total_tp+total_fn)>0 else 0.0
    f1 = 2*prec*rec/(prec+rec) if (prec+rec)>0 else 0.0
    return {"per_type":per_type,"precision":prec,"recall":rec,"f1":f1}
def main():
    if len(sys.argv)!=2: print("Usage: python3 grade.py path/to/report.json"); return
    truth = load_truth("instructor/labels.json"); pred = load_student(sys.argv[1])
    res = score(truth,pred)
    print("=== GNSS Lab Grading ===")
    for t,tp,fn,fp in res["per_type"]:
        print(f"{t:28s} TP:{tp}  FN:{fn}  FP:{fp}")
    print(f"\nPrecision: {res['precision']:.2f}  Recall: {res['recall']:.2f}  F1: {res['f1']:.2f}")
    print("PASS" if res["f1"]>=0.70 else "KEEP WORKING")
if __name__ == "__main__": main()
