from flask import Flask, render_template, jsonify
import requests, os, time

app = Flask(__name__)

CUBES = [1,2,3]
CUBES_HOST = os.environ.get("CUBES_HOST", "cubesat{}:5005")

@app.route('/')
def index():
    statuses = []
    for n in CUBES:
        try:
            # Attempt to reach cubesat via a simple status UDP-less ping (we don't have an HTTP endpoint on cubesat in this simple lab)
            # We'll just report "reachable" by resolving DNS via socket (skip actual network check for simplicity)
            statuses.append({"node": n, "status": "running"})
        except Exception:
            statuses.append({"node": n, "status": "unknown"})
    return render_template('index.html', statuses=statuses)

@app.route('/api/status')
def status_api():
    sts = [{"node": n, "status": "running"} for n in CUBES]
    return jsonify(sts)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)
