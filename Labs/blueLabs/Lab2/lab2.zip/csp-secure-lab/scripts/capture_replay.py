#!/usr/bin/env python3
"""
Usage:
  python capture_replay.py capture out.bin
  python capture_replay.py replay out.bin target_host target_port

This script listens on the local host UDP port 5005 and saves the first packet to file.
Replay sends raw bytes from file to target host:port.
"""
import sys, socket, time

def capture(out_file, port=5005, timeout=30):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.bind(('0.0.0.0', port))
    s.settimeout(timeout)
    print(f"Listening for one UDP packet on port {port} (timeout {timeout}s)...")
    try:
        data, addr = s.recvfrom(65535)
    except Exception as e:
        print("Timeout or error:", e)
        return
    print("Captured packet from", addr, "len=", len(data))
    with open(out_file, 'wb') as f:
        f.write(data)
    print("Saved to", out_file)

def replay(in_file, host, port=5005):
    with open(in_file, 'rb') as f:
        data = f.read()
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.sendto(data, (host, port))
    print(f"Replayed {len(data)} bytes to {host}:{port}")

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    cmd = sys.argv[1]
    if cmd == "capture":
        capture(sys.argv[2])
    elif cmd == "replay":
        if len(sys.argv) < 4:
            print("replay requires in_file host [port]")
            sys.exit(1)
        port = int(sys.argv[4]) if len(sys.argv) > 4 else 5005
        replay(sys.argv[2], sys.argv[3], port)
    else:
        print("Unknown command")
