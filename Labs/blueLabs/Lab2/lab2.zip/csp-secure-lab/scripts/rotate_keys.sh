#!/usr/bin/env bash
# Generate a new 128-bit key (hex) and restart containers with updated env
NEWKEY=$(xxd -l 16 -p /dev/urandom)
echo "New key: $NEWKEY"

# This lab uses docker-compose; we pass new env via docker-compose.override or recreate containers.
# For simplicity: stop containers, set env files, and bring up again.

# Create .env file used by docker-compose via environment variable expansion (we'll set XTEA_KEY_HEX used at runtime)
cat > .env <<EOF
XTEA_KEY_HEX=${NEWKEY}
ENABLE_ENCRYPTION=true
ENABLE_SEQUENCE_WINDOW=true
EOF

echo ".env created. Restarting docker-compose..."
docker-compose down
docker-compose up -d --build

echo "Containers restarted with new key (ENV)."
echo "NOTE: In this simplified lab, each container reads env at startup. Ensure containers were recreated."
