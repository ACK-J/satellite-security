\# CSP Secure Lab



\## Purpose

Hands-on lab to demonstrate insecure CSP-like communication and hardening via XTEA encryption and sequence-window replay protection.



\## How to run

1\. Build and start:



```bash

docker-compose build

docker-compose up

```



2\. Open Mission Ops UI: http://localhost:8080

3\. Watch logs for cubesat1..3:



```bash

docker logs -f cubesat1

```



4\. Capture packets in Wireshark: filter `udp.port == 5005`.

