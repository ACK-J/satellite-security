#!/bin/sh
# Minimal entrypoint: rely on csp_service.py reading env vars
NODE_ID=${NODE_ID:-1}
LISTEN_PORT=${LISTEN_PORT:-5005}

echo "Starting CubeSat Node $NODE_ID on UDP port $LISTEN_PORT"
# Run the start script with the default config path (csp_service.py will read env vars)
exec /opt/csp/start_csp.sh /opt/csp/csp_config.json
