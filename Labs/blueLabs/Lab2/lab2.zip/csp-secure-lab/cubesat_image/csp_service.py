#!/usr/bin/env python3
"""
Simple CSP-like UDP beacon service.
Sends periodic beacons to broadcast (all peers) and listens for incoming beacons.
Supports optional XTEA encryption and a simple sequence-window replay defense.

Payload format (binary):
  4 bytes seq (big-endian unsigned int)
  1 byte node_id
  remaining bytes: message (UTF-8) encrypted if enabled
"""

import argparse
import json
import os
import socket
import struct
import threading
import time
from datetime import datetime

# --- XTEA implementation (64-bit block, 128-bit key) ---
def xtea_encrypt_block(v, k, rounds=32):
    v0, v1 = v
    delta = 0x9E3779B9
    sumv = 0
    for _ in range(rounds):
        v0 = (v0 + (((v1 << 4) ^ (v1 >> 5)) + v1) ^ (sumv + k[sumv & 3])) & 0xFFFFFFFF
        sumv = (sumv + delta) & 0xFFFFFFFF
        v1 = (v1 + (((v0 << 4) ^ (v0 >> 5)) + v0) ^ (sumv + k[(sumv>>11) & 3])) & 0xFFFFFFFF
    return v0, v1

def xtea_decrypt_block(v, k, rounds=32):
    v0, v1 = v
    delta = 0x9E3779B9
    sumv = (delta * rounds) & 0xFFFFFFFF
    for _ in range(rounds):
        v1 = (v1 - ((((v0 << 4) ^ (v0 >> 5)) + v0) ^ (sumv + k[(sumv>>11) & 3]))) & 0xFFFFFFFF
        sumv = (sumv - delta) & 0xFFFFFFFF
        v0 = (v0 - ((((v1 << 4) ^ (v1 >> 5)) + v1) ^ (sumv + k[sumv & 3]))) & 0xFFFFFFFF
    return v0, v1

def xtea_encrypt(data: bytes, key_bytes: bytes) -> bytes:
    out = bytearray()
    k = struct.unpack('>4I', key_bytes)
    pad = (8 - (len(data) % 8)) % 8
    data = data + bytes([pad])*pad
    for i in range(0, len(data), 8):
        block = struct.unpack('>2I', data[i:i+8])
        enc = xtea_encrypt_block(block, k)
        out.extend(struct.pack('>2I', *enc))
    return bytes(out)

def xtea_decrypt(data: bytes, key_bytes: bytes) -> bytes:
    out = bytearray()
    k = struct.unpack('>4I', key_bytes)
    for i in range(0, len(data), 8):
        block = struct.unpack('>2I', data[i:i+8])
        dec = xtea_decrypt_block(block, k)
        out.extend(struct.pack('>2I', *dec))
    if not out:
        return b''
    pad = out[-1]
    if pad <= 8:
        return bytes(out[:-pad])
    return bytes(out)

# --- CSP-like service ---
class CSPNode:
    def __init__(self, cfg):
        self.node_id = int(cfg.get("node_id", 1))
        self.listen_port = int(os.environ.get("LISTEN_PORT", cfg.get("listen_port", 5005)))
        self.peers = cfg.get("peers", [1,2,3])
        self.beacon_interval = cfg.get("beacon_interval_s", 3)
        self.enable_enc = bool(cfg.get("enable_encryption", False))
        key_hex = cfg.get("xtea_key_hex", "00112233445566778899aabbccddeeff")
        self.xtea_key = bytes.fromhex(key_hex)
        self.sequence_window = bool(cfg.get("sequence_window", False))
        self.seq_window_size = int(cfg.get("sequence_window_size", 8))
        self.seq = 1
        self.last_seen = {}  

        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

        self.sock.bind(('0.0.0.0', self.listen_port))

    def make_packet(self, seq, node_id, msg_text):
        payload = msg_text.encode('utf-8')

        header = struct.pack('>I', seq) + struct.pack('B', node_id)
        if self.enable_enc:
            enc = xtea_encrypt(payload, self.xtea_key)
            return header + enc
        else:
            return header + payload

    def parse_packet(self, pkt_bytes):
        if len(pkt_bytes) < 5:
            return None
        seq = struct.unpack('>I', pkt_bytes[:4])[0]
        node_id = pkt_bytes[4]
        body = pkt_bytes[5:]
        if self.enable_enc:

            try:
                dec = xtea_decrypt(body, self.xtea_key)
            except Exception:
                return None
            try:
                text = dec.decode('utf-8', errors='ignore')
            except:
                text = "<non-utf8>"
        else:
            text = body.decode('utf-8', errors='ignore')
        return {"seq": seq, "node_id": node_id, "text": text}

    def send_beacon(self):

        for peer in self.peers:

            if peer == self.node_id:
                continue
            target = f'cubesat{peer}'
            try:

                self.sock.sendto(self.make_packet(self.seq, self.node_id, f"beacon from {self.node_id} {datetime.utcnow().isoformat()}"), (target, self.listen_port))
            except Exception as e:

                pass
        print(f"[node {self.node_id}] sent beacon seq={self.seq}")
        self.seq += 1

    def receiver_loop(self):
        while True:
            try:
                data, addr = self.sock.recvfrom(4096)
            except Exception:
                continue
            parsed = self.parse_packet(data)
            if not parsed:

                print(f"[node {self.node_id}] dropped non-parseable packet from {addr}")
                continue
            src = parsed["node_id"]
            seq = parsed["seq"]
            text = parsed["text"]

            if self.sequence_window:
                last = self.last_seen.get(src, 0)

                if seq <= last:
                    print(f"[node {self.node_id}] dropped replay or old seq from {src}: seq={seq} last={last}")
                    continue
                if seq > last + self.seq_window_size:
                    print(f"[node {self.node_id}] dropped out-of-window seq from {src}: seq={seq} last={last}")
                    continue
                self.last_seen[src] = seq
            else:
                self.last_seen[src] = seq
            print(f"[node {self.node_id}] received from {src} seq={seq} msg='{text[:60]}'")

    def run(self):
        t = threading.Thread(target=self.receiver_loop, daemon=True)
        t.start()
        
        while True:
            self.send_beacon()
            time.sleep(self.beacon_interval)

# --- CLI config ---
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="/opt/csp/csp_config.json")
    args = parser.parse_args()
    with open(args.config, 'r') as f:
        cfg = json.load(f)

    if "NODE_ID" in os.environ:
        cfg["node_id"] = int(os.environ["NODE_ID"])
    if "LISTEN_PORT" in os.environ:
        cfg["listen_port"] = int(os.environ["LISTEN_PORT"])
    if "ENABLE_ENCRYPTION" in os.environ:
        cfg["enable_encryption"] = (os.environ["ENABLE_ENCRYPTION"].lower() == "true")
    if "XTEA_KEY_HEX" in os.environ:
        cfg["xtea_key_hex"] = os.environ["XTEA_KEY_HEX"]
    if "ENABLE_SEQUENCE_WINDOW" in os.environ:
        cfg["sequence_window"] = (os.environ["ENABLE_SEQUENCE_WINDOW"].lower() == "true")

    node = CSPNode(cfg)
    node.run()
