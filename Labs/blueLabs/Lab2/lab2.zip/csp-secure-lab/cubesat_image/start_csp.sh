#!/bin/sh
CONFIG_PATH="$1"
/usr/bin/env python3 /opt/csp/csp_service.py --config "$CONFIG_PATH"
